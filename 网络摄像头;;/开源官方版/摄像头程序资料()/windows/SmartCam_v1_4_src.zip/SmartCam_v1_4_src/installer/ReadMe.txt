1)	
- What's new in version 1.4?

* Higher resolution support (320 x 240) based on Movino (http://movino.org/) implementation of libjpeg encoding
* The java version (jSmartCam) is no longer compatible

- What's new in version 1.3?

* WiFi version available. New versions (1.3) of the S60 2nd Ed and 3rd Ed applications.
However the java version (jSmartCam) has not changed, and still only supports bluetooth
connectivity.
* Several defects were fixed.

- What's new in version 1.2?

* S60 3rd Edition version available.
* Several defects were fixed.

- What's new in version 1.1?

* Several bugs in the DirectShow filter are now fixed, allowing SmartCam to work with Skype and MSN.
* J2ME application (jSmartCam) now available.

2)	Setting up the J2ME application on the phone:

-	By default jSmartCam will ask for the user's permission
the first time it uses the Bluetooth and before capturing every
frame from the camera. To prevent this, just go to the application
manager, select jSmartCam -> Settings (or Suite settings) :
	* Connectivity : Always allowed
	* Multimedia   : Ask first time

-	To speed up the connection, in the discovery screen, select
the desired PC, then Options->Set default. The next time jSmartCam 
will connect, it will directly connect to the selected default device,
without discovering other devices.

3)	How to connect via WiFi?

The easiest way is to use an external WiFi access point. Start the PC application,
then go to File->Settings->Connection and select TCP/IP (WiFi). Then start the phone
application, select Options->Connect->TCP/IP (WiFi). Then enter the IP address of your
PC (you can copy it so you can easily paste it the next time you connect). 
The phone will next ask you to select an access point. Select here the WiFi access point
that corresponds to your wireless router. If everything goes ok SmartCam should successfully
connect. Alternately, if you don't have a wireless router, but have a USB WiFi dongle for
your PC or a laptop with WiFi connectivity you can still use SmartCam via WiFi, you'll just
need to set up an Ad Hoc access point on your PC/laptop. This is not as easy and doesn't
always work..

ENJOY :-)