/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// UserSettings.cpp

#include "StdAfx.h"
#include <winreg.h>

#include "UserSettings.h"

#define SMARTCAM_REG_KEY "Software\\SmartCam\0"
#define SMARTCAM_REG_CONN_TYPE_VAL_NAME "ConnectionType\0"
#define SMARTCAM_REG_INET_PORT_VAL_NAME "InetPort\0"
#define SMARTCAM_REG_VIDEO_CODEC_VAL_NAME "VideoCodec\0"

#define DEFAULT_TCP_PORT 9361

// Constructor, loads with default user settings
CUserSettings::CUserSettings():
    connectionType(CONN_INET),//(CONN_BLUETOOTH),
    inetPort(DEFAULT_TCP_PORT),
    videoCodec(CODEC_NONE)
{
}

CUserSettings::CUserSettings(const CUserSettings& settings):
    connectionType(settings.connectionType),
    inetPort(settings.inetPort),
    videoCodec(settings.videoCodec)
{
}

CUserSettings& CUserSettings::operator=(const CUserSettings& settings)
{
    if(this != &settings)
    {
        connectionType = settings.connectionType;
        inetPort = settings.inetPort;
        videoCodec = settings.videoCodec;
    }
    return *this;
}

CUserSettings::~CUserSettings()
{
}

HKEY CUserSettings::OpenRegKey()
{
    HKEY hKey = NULL;
    DWORD disposition;
    LONG result = RegCreateKeyEx(
                        HKEY_CURRENT_USER,
                        SMARTCAM_REG_KEY,
                        0,
                        NULL,
                        REG_OPTION_NON_VOLATILE,
                        KEY_ALL_ACCESS,
                        NULL,
                        &hKey,
                        &disposition);
    if(result != ERROR_SUCCESS)
    {
        OutputDebugString("Error accessing registry key\n");
    }
    return hKey;
}

int CUserSettings::ReadRegValue(HKEY hKey, LPCTSTR lpValueName)
{
    DWORD dwType = REG_DWORD;
    DWORD regData = 0;
    DWORD dataSize = sizeof(DWORD);

    LONG result = RegQueryValueEx(hKey, lpValueName, NULL, &dwType, (LPBYTE) &regData, &dataSize);
    if(result == ERROR_SUCCESS)
        return regData;
    else if(result != ERROR_FILE_NOT_FOUND)
    {
        OutputDebugString("Error accessing registry value\n");
    }
    return -1;
}

CUserSettings CUserSettings::LoadSettings()
{
    CUserSettings regSettings; // default settings constructor
    int regData = 0;
    HKEY hKey = CUserSettings::OpenRegKey();
    if(hKey == NULL)
    {
        return regSettings;
    }

    // ConnectionType
    regData = CUserSettings::ReadRegValue(hKey, SMARTCAM_REG_CONN_TYPE_VAL_NAME);
    if(regData != -1)
        regSettings.connectionType = (ConnectionType) regData;
    // InetPort
    regData = CUserSettings::ReadRegValue(hKey, SMARTCAM_REG_INET_PORT_VAL_NAME);
    if(regData != -1)
        regSettings.inetPort = regData;
    // VideoCodec
    regData = CUserSettings::ReadRegValue(hKey, SMARTCAM_REG_VIDEO_CODEC_VAL_NAME);
    if(regData != -1)
        regSettings.videoCodec = (VideoCodec) regData;

    RegCloseKey(hKey);
    return regSettings;
}

void CUserSettings::SaveSettings(CUserSettings settings)
{
    HKEY hKey = CUserSettings::OpenRegKey();
    if(hKey == NULL)
        return;
    RegSetValueEx(hKey, SMARTCAM_REG_CONN_TYPE_VAL_NAME, 0, REG_DWORD, (const BYTE *) &settings.connectionType, 4);
    RegSetValueEx(hKey, SMARTCAM_REG_INET_PORT_VAL_NAME, 0, REG_DWORD, (const BYTE *) &settings.inetPort, 4);
    RegSetValueEx(hKey, SMARTCAM_REG_VIDEO_CODEC_VAL_NAME, 0, REG_DWORD, (const BYTE *) &settings.videoCodec, 4);
    RegCloseKey(hKey);
}
