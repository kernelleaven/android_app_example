/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// UIHandler.h

#ifndef __UI_HANDLER_H__
#define __UI_HANDLER_H__

#include <shellapi.h>	// Tray icon
#include <commdlg.h>	// GetOpenFileName
#include <commctrl.h>

#include <string>
#include <vector>
#include <GdiPlus.h>

#include "resource.h"
#include "..\common\commoncam.h"

using namespace std;
using namespace Gdiplus;


// Functions:
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SettingsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK VideoWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

class CSmartEngine;

class CUIHandler
{
public:
    CUIHandler(CSmartEngine* pEngine, HINSTANCE hInst);
    virtual ~CUIHandler();
    int Initialize();
    int CreateMainWnd(int nCmdShow);
    HWND GetHWNDMainWnd();
    HWND GetHWNDVideoWnd();
    HBITMAP GetHBITMAPLogo();
    Bitmap* GetLogoBmp();
    WNDPROC GetOrigVideoWndProc();
    void UpdateOnDisconnected();
    void UpdateOnConnected();
    void UpdateOnNoNetwork();
    void UpdateStatusBarIcon();
    void UpdateFPS(char* fps_str);
	void UpdateResolution(int width, int height);
    void DrawFrame(Bitmap* frame);
	void UpdateOnCaptureStarted();
	void UpdateOnCaptureStopped();
    void Cleanup();

    BOOL OpenFileDialog(char* fileName, int fileNameMaxLen);

    static void CenterWindow(HWND hwndChild, HWND hwndParent);
	static void Msg(const TCHAR *szFormat, ...);
	
	static const int APPWM_TRAYICON = WM_APP;

private:
    void LoadIcons();
    void DestroyIcons();

    void CreateStatusBar();
    void CreateToolBar();
    void CreateVideoWnd();

    void RegisterMainWndClass();
    void UnregisterMainWndClass();

    void CreateModifyTrayIcon(HICON hTrayIcon, const char* tooltip, BOOL create);
    void RemoveTrayIcon();

    // Data:
    CSmartEngine* pSmartEngine;
    HINSTANCE hInstance;
    HWND hMainWnd;				// Main application window
    HFONT hFont;				// Main application font
    HWND hStatusBarWnd;
    HWND hToolBarWnd;
    HWND hVideoWnd;

    HIMAGELIST hTBarImgList;
    HIMAGELIST hTBarDisabledImgList;

    HICON hIconConnected;
    HICON hIconDisconnected;
    HICON hIconNoNetwork;
    HICON hIconConnBt;
    HICON hIconConnInet;
    Bitmap* bmpLogo;
    HBITMAP hLogoBmp;

    WNDPROC wpOrigVideoWndProc;

    // Window sizes:
    static const int WND_WIDTH = 335;
    static const int WND_HEIGHT = 365;
    static const int VIDEO_WND_WIDTH = 292;
    static const int VIDEO_WND_HEIGHT = 219;

    static const int ID_STATUSBAR = 1;
    static const int ID_TOOLBAR = 2;

    // Tray icon:
    static const int ID_TRAYICON = 1;
    static const char* TRAY_TOOLTIP_CONNECTED;
    static const char* TRAY_TOOLTIP_DISCONNECTED;
    static const char* TRAY_TOOLTIP_NO_NETWORK;

    static const int NUM_TBAR_BUTTONS = 6;
    static const TBBUTTON tbButtons[NUM_TBAR_BUTTONS];
};


#endif//__UI_HANDLER_H__
