/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDC_MYICON                              2
#define IDD_ABOUTBOX                            103
#define IDM_ABOUT                               104
#define IDM_EXIT                                105
#define IDI_CONNECTED                           107
#define IDC_SMARTCAM                            109
#define IDI_START_CAPTURE                       130
#define IDI_STOP_CAPTURE                        131
#define IDI_START_CAPTURE_DISABLED              132
#define IDI_STOP_CAPTURE_DISABLED               133
#define IDB_BMP_LOGO                            134
#define IDI_DISCONNECTED                        135
#define IDI_NO_NETWORK                          136
#define IDD_SETTINGS                            138
#define IDI_DISCONNECT                          140
#define IDI_DISCONNECT_DISABLED                 142
#define IDI_SETTINGS                            144
#define IDI_CONN_BT                             145
#define IDI_CONN_INET                           146
#define IDI_ABOUT_SMARTCAM                      147
#define IDM_START_CAPTURE                       32772
#define IDM_STOP_CAPTURE                        32773
#define IDM_DISCONNECT                          32774
#define IDM_SETTINGS                            40000
#define IDS_APP_TITLE                           40000
#define IDS_TTIP_SETTINGS                       40001
#define IDS_TTIP_START_CAPTURE                  40002
#define IDS_TTIP_STOP_CAPTURE                   40003
#define IDS_TTIP_DISCONNECT                     40004
#define IDC_RB_BLUETOOTH                        40005
#define IDC_RB_INET                             40006
#define IDC_STATIC_PORT                         40008
#define IDC_EDIT_PORT                           40009
#define IDC_CODEC_NONE                          40010
#define IDC_CODEC_CINEPAK                       40011
#define IDC_CODEC_DIVX                          40012
