/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// DShowHandler.cpp

#include "StdAfx.h"

#include "DShowHandler.h"
#include "SmartEngine.h"
#include "UIHandler.h"

#define SAFE_RELEASE(x) { if (x) { x->Release(); x = NULL; } }

const char* CDShowHandler::CINEPAK_CODEC_DISPLAY_NAME = "@device:cm:{33D9A760-90C8-11D0-BD43-00A0C911CE86}\\cvid";
const char* CDShowHandler::DIVX_CODEC_DISPLAY_NAME = "@device:cm:{33D9A760-90C8-11D0-BD43-00A0C911CE86}\\divx";

CDShowHandler::CDShowHandler(CSmartEngine* pEngine):
	pSmartEngine(pEngine),
	pSrcFilter(NULL),
	pMC(NULL),
	pME(NULL),
	pGraph(NULL),
	pCaptureGraph(NULL),
	pMux(NULL),
	pCodec(NULL),
	pFileSincFilter(NULL)
{
}

CDShowHandler::~CDShowHandler()
{
}

int CDShowHandler::Initialize()
{
    HRESULT hr;
    // Get DirectShow interfaces
    hr = GetInterfaces();
    if(FAILED(hr))
    {
		CUIHandler::Msg("Failed to get video interfaces! Error code 0x%x", hr);
        return -1;
    }

    // Attach the filter graph to the capture graph
    hr = pCaptureGraph->SetFiltergraph(pGraph);
    if(FAILED(hr))
    {
        CUIHandler::Msg("Failed to set capture filter graph! Error code 0x%x", hr);
        return -1;
    }

    hr = CoCreateInstance(CLSID_SmartCam, 0, CLSCTX_INPROC_SERVER,
                          IID_IBaseFilter, reinterpret_cast<void**>(&pSrcFilter));
    if(FAILED(hr))
    {
		CUIHandler::Msg("SmartCam filter not found, reinstalling the application may fix this problem. Error code 0x%x", hr);
        return -1;
    }
    hr = pGraph->AddFilter(pSrcFilter, L"Video Capture");
    if(FAILED(hr))
	{
		CUIHandler::Msg("Could not render SmartCam! Error code 0x%x", hr);
        return -1;
	}

	return 0;
}

void CDShowHandler::Cleanup()
{
	CloseInterfaces();
}

BOOL CDShowHandler::IsDivXCodecInstalled()
{
	return IsCodecInstalled(DIVX_CODEC_DISPLAY_NAME);
}

BOOL CDShowHandler::IsCinepakCodecInstalled()
{
	return IsCodecInstalled(CINEPAK_CODEC_DISPLAY_NAME);
}

HRESULT CDShowHandler::GetInterfaces()
{
    HRESULT hr;

    // Create the filter graph
    hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC,
                           IID_IGraphBuilder, (void **) &pGraph);
    if (FAILED(hr))
        return hr;

    // Create the capture graph builder
    hr = CoCreateInstance(CLSID_CaptureGraphBuilder2 , NULL, CLSCTX_INPROC,
                           IID_ICaptureGraphBuilder2, (void **) &pCaptureGraph);
    if (FAILED(hr))
        return hr;

    return hr;
}

void CDShowHandler::CloseInterfaces()
{
    // Stop receiving events
    if(pME)
        pME->SetNotifyWindow(NULL, WM_GRAPHNOTIFY, 0);

    // Release DirectShow interfaces
	SAFE_RELEASE(pSrcFilter);
	SAFE_RELEASE(pCodec);
    SAFE_RELEASE(pMC);
    SAFE_RELEASE(pME);
	SAFE_RELEASE(pCaptureGraph);
    SAFE_RELEASE(pGraph);
}

IBaseFilter* CDShowHandler::CreateCodecFromDisplayName(const char* displayName)
{
	IBaseFilter* pResultCodec = NULL;
	IBindCtx * pBindCtx = NULL;
	HRESULT hr = CreateBindCtx(0, &pBindCtx);
	if(FAILED(hr))
	{
		DbgOutString("Could not create bind context ...");
		return NULL;
	}

	IMoniker* pMonikerCodec;
	WCHAR wszDisplayName[1024];
	MultiByteToWideChar(CP_ACP, 0, displayName, -1, wszDisplayName, 1024);

	DWORD dwEaten;
	hr = MkParseDisplayName(pBindCtx, wszDisplayName, &dwEaten, &pMonikerCodec);
	if(FAILED(hr))
	{
		DbgOutString("Could not parse codec display name ...");
		pBindCtx->Release();
		return NULL;
	}
	hr = pMonikerCodec->BindToObject(NULL, NULL, IID_IBaseFilter, (void**)&pResultCodec);
	if(FAILED(hr))
	{
		DbgOutString("Could not bind codec to object ...");
		pMonikerCodec->Release();
		pBindCtx->Release();
		return NULL;
	}
	pMonikerCodec->Release();
	pBindCtx->Release();
	return pResultCodec;
}

BOOL CDShowHandler::IsCodecInstalled(const char* codecDisplayName)
{
	BOOL codecFound = FALSE;
	WCHAR* wszDisplayName = NULL;
    HRESULT hr;
	ULONG cFetched = 0;

    // Create the system device enumerator
    CComPtr<ICreateDevEnum> pDevEnum = NULL;
    CComPtr<IMoniker> pMoniker = NULL;

    hr = CoCreateInstance (CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC,
                           IID_ICreateDevEnum, (void **) &pDevEnum);
    if (FAILED(hr))
    {
        DbgOutString("Couldn't create system enumerator ...");
        return FALSE;
    }

    // Create an enumerator for the video codecs
    CComPtr<IEnumMoniker> pClassEnum = NULL;

    hr = pDevEnum->CreateClassEnumerator(CLSID_VideoCompressorCategory, &pClassEnum, 0);
    if(FAILED(hr))
    {
		pDevEnum.Release();
        DbgOutString("Couldn't create class enumerator ...");
        return FALSE;
    }

    // If there are no enumerators for the requested type, then 
    // CreateClassEnumerator will succeed, but pClassEnum will be NULL.
    if(pClassEnum == NULL)
    {
		pDevEnum.Release();
        DbgOutString("No video compressors were detected ...");
        return FALSE;
    }

	pDevEnum.Release();

	IBindCtx * pBindCtx = NULL;
	CreateBindCtx(0, &pBindCtx);

    while(pClassEnum->Next(1, &pMoniker, &cFetched) == S_OK)
    {
		CComPtr<IPropertyBag> pPropBag;
        // Bind Moniker to a property bag object
        hr = pMoniker->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pPropBag);
        if(FAILED(hr))
		{
			pMoniker.Release();
            continue;
		}

        // Read filter name from property bag
		USES_CONVERSION;
		// Retrieve the friendly name of the filter
		VARIANT varName;
		VariantInit(&varName);

		// Get filter display name
		hr = pMoniker->GetDisplayName(pBindCtx, NULL, &wszDisplayName);
        if(FAILED(hr))
		{
			pPropBag.Release();
			pMoniker.Release();
            continue;
		}

		string displayName = W2T(wszDisplayName);
		CoTaskMemFree(wszDisplayName);
        // Cleanup interfaces
		pPropBag.Release();
		pMoniker.Release();
		if(displayName == codecDisplayName)
		{
			codecFound = TRUE;
			break;
		}
    }
	pBindCtx->Release();
	pClassEnum.Release();
    return codecFound;
}

int CDShowHandler::StartFileCapture(const char* captureFileName)
{
	HRESULT hr;
	WCHAR wFileName[CSmartEngine::CAPTURE_FILE_NAME_MAX_LEN];
	MultiByteToWideChar(CP_ACP, 0, captureFileName, -1, wFileName, CSmartEngine::CAPTURE_FILE_NAME_MAX_LEN);

	IBaseFilter* pMux = NULL;

	hr = pCaptureGraph->SetOutputFileName(
								&MEDIASUBTYPE_Avi,	// Specifies AVI for the target file.
								wFileName,			// File name.
								&pMux,				// Receives a pointer to the AVI mux filter.
								NULL);//&g_pFileSincFilter);// (Optional) Receives a pointer to the file sink.
    if(FAILED(hr))
		goto capture_error;

	SAFE_RELEASE(pCodec);
	switch(pSmartEngine->GetSettings().videoCodec)
	{
	case CODEC_CINEPAK:
		{
		pCodec = CreateCodecFromDisplayName(CINEPAK_CODEC_DISPLAY_NAME);
		break;
		}
	case CODEC_DIVX:
		{
		pCodec = CreateCodecFromDisplayName(DIVX_CODEC_DISPLAY_NAME);
		break;
		}
	case CODEC_NONE:
		{
		pCodec = NULL;
		break;
		}
	}

	if(pCodec != NULL)
	{
		hr = pGraph->AddFilter(pCodec, L"Video codec");
		if(FAILED(hr))
			goto capture_error;
	}

	hr = pCaptureGraph->RenderStream(&PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video,
									 pSrcFilter, pCodec, pMux);
    if(FAILED(hr))
		goto capture_error;

    // Now that the filter has been added to the graph and we have
    // rendered its stream, we can release the reference to the AVI mux.
	SAFE_RELEASE(pMux);

    // Obtain interface for media control
    hr = pGraph->QueryInterface(IID_IMediaControl,(LPVOID *) &pMC);
	if(FAILED(hr))
		goto capture_error;

	// Start capturing video data
    hr = pMC->Run();
    if(FAILED(hr))
		goto capture_error;

	SAFE_RELEASE(pMC);
    return 0;

capture_error:
	CUIHandler::Msg("Could not start video capture! Error code 0x%x", hr);
	NukeDownstream(pSrcFilter);
    return -1;
}

void CDShowHandler::StopFileCapture()
{
    // Obtain interface for media control
    HRESULT hr = pGraph->QueryInterface(IID_IMediaControl,(LPVOID *) &pMC);
	if(FAILED(hr))
		return;

    // See whether not already stopped
	OAFilterState fState;
	hr = pMC->GetState(INFINITE, &fState);
    if(FAILED(hr) || fState == State_Stopped)
	{
		SAFE_RELEASE(pMC);
		NukeDownstream(pSrcFilter);
		return;
	}

	hr = pMC->Stop();

	SAFE_RELEASE(pMC);
	NukeDownstream(pSrcFilter);
}

// Tear down everything downstream of a given filter
void CDShowHandler::NukeDownstream(IBaseFilter* pf)
{
	IPin *pP=0, *pTo=0;
	ULONG u;
	IEnumPins *pins = NULL;
	PIN_INFO pininfo;

	if(!pf)
		return;

	HRESULT hr = pf->EnumPins(&pins);
	pins->Reset();

	while(hr == NOERROR)
	{
		hr = pins->Next(1, &pP, &u);
		if(hr == S_OK && pP)
		{
			pP->ConnectedTo(&pTo);
			if(pTo)
			{
				hr = pTo->QueryPinInfo(&pininfo);
				if(hr == NOERROR)
				{
					if(pininfo.dir == PINDIR_INPUT)
					{
						NukeDownstream(pininfo.pFilter);
						pGraph->Disconnect(pTo);
						pGraph->Disconnect(pP);
						pGraph->RemoveFilter(pininfo.pFilter);
					}
					pininfo.pFilter->Release();
				}
				pTo->Release();
			}
			pP->Release();
		}
	}

	if(pins)
		pins->Release();
}
