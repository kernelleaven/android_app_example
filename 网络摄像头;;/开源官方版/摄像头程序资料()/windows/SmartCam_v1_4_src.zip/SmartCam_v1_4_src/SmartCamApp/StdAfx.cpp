/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// StdAfx.cpp : source file that includes just the standard includes
// BlueCam.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

namespace ATL {
    void * __stdcall __AllocStdCallThunk()
    {
        return HeapAlloc(GetProcessHeap(),
            0, sizeof(_stdcallthunk));
    }

    void __stdcall __FreeStdCallThunk(void *p)
    {
        HeapFree(GetProcessHeap(), 0, p);
    }
}

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
