/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// SmartEngine.h

#ifndef __SMART_ENGINE_H__
#define __SMART_ENGINE_H__

#include <GdiPlus.h>

#include "UserSettings.h"

using namespace Gdiplus;

class CCommHandler;
class CUIHandler;
class CDShowHandler;
class CJpegHandler;

class CSmartEngine
{
public:
    CSmartEngine(HINSTANCE hInst);
    virtual ~CSmartEngine();
    int Initialize();
    void Cleanup();
    int StartUI(int nCmdShow);
    int StartCommThread();
    void StopCommThread();
    int Disconnect();
    HINSTANCE GetHInstance();
    HWND GetHWNDMainWnd();
    HBITMAP GetHBITMAPLogo();
    Bitmap* GetLogoBmp();
    WNDPROC GetOrigVideoWndProc();
    void HandleGraphEvent();
    void OnConnected();
    void OnDisconnected();
    BOOL IsConnected();
    BOOL IsCaptureStarted();
    CUserSettings GetSettings();
    void SaveSettings(CUserSettings settings);
	BOOL IsDivXCodecInstalled();
	BOOL IsCinepakCodecInstalled();
	void StartFileCapture();
	void StopFileCapture();

	static const int CAPTURE_FILE_NAME_MAX_LEN = 512;

private:
    // Functions:
    int AllocMem();
    void FreeMem();
	int StartServer();
	void AcceptClient();
    int RcvPacket();
    void ProcessPacket();
	void ShareFrame(Bitmap* bmpFrame);
	void ShareFrame(Bitmap* bmpFrame, int frameNo);
    void PreviewFrame(Bitmap* bmpFrame);
	void SampleFPS();
    void ExitApp();
    // Comm thread procedure:
    static DWORD WINAPI CommThreadProc(LPVOID lpParam);

    // Data:
	HANDLE hSingleInstSem;
    ULONG_PTR gdiplusToken;
    // Shared memory data:
    LPVOID pSharedMem;
    HANDLE hFileMapping;
    Bitmap* pSharedMemBmp;
    // Frame number
    int frameNumber;
	int crtWidth;
	int crtHeight;
	unsigned long lastSampleTimeMillis;
	int crtSampleFrames;
    // Comm thread
    BOOL isAlive;
    HANDLE hCommThread;
    CCommHandler* pCommHandler;
    CJpegHandler* pJpegHandler;
    CUIHandler* pUIHandler;
	CDShowHandler* pDShowHandler;
    HINSTANCE hInstance;
    CUserSettings crtSettings;
	// File capture:
	char captureFileName[CAPTURE_FILE_NAME_MAX_LEN];
};
#endif//__SMART_ENGINE_H__
