/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// CommHandler.cpp

#include "StdAfx.h"

#include "CommHandler.h"
#include "SmartEngine.h"
#include "UIHandler.h"

// Constructor
CCommHandler::CCommHandler(CSmartEngine* pEngine):
    pSmartEngine(pEngine),
	isConnected(FALSE),
	serverSocket(INVALID_SOCKET),
	clientSocket(INVALID_SOCKET),
    rcvPacket(NULL),
    rcvPacketLen(0),
    rcvPacketMaxLen(0)
{
}

// Destructor
CCommHandler::~CCommHandler()
{
}

int CCommHandler::Initialize()
{
	// Initialize WinSock2
	HRESULT hr = InitWinSock2();
	if(FAILED(hr))
		return -1;
    rcvPacket = new BYTE[DEFAULT_PAKET_MAX_LEN];
	if(rcvPacket == NULL)
		return -1;
	rcvPacketMaxLen = DEFAULT_PAKET_MAX_LEN;
	return 0;
}

int CCommHandler::InitWinSock2()
{
	// initialize WinSock 2
	WORD wVersionRequested;	// Highest version of Windows Sockets support that the caller can use
	WSADATA wsaData;		// Pointer to the WSADATA data structure that is to receive details
							// of the Windows Sockets implementation.
	int err;

	wVersionRequested = MAKEWORD( 2, 2 );

	err = WSAStartup( wVersionRequested, &wsaData );
	if(err != 0)
	{
        CUIHandler::Msg("Could not find a usable WinSock DLL\n");
		return err;
	}

	// Confirm that the WinSock DLL supports 2.2
	// Note that if the DLL supports versions greater
	// than 2.2 in addition to 2.2, it will still return
	// 2.2 in wVersion since that is the version we requested

	if(LOBYTE( wsaData.wVersion ) != 2 ||
       HIBYTE( wsaData.wVersion ) != 2 )
	{
		// Tell the user that we could not find a usable WinSock DLL
		CUIHandler::Msg("Could not find a usable WinSock DLL v 2.2\n");
		WSACleanup();
		return -1;
	}
	// The WinSock DLL is acceptable. Return success
	return 0;
}

int CCommHandler::StartInetServer(int port)
{
	int retCode = 0;
	SOCKADDR_IN sin;
    // Initialize the addr
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = 0;
    sin.sin_port = htons(port);

	serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(serverSocket == INVALID_SOCKET)
	{
		retCode = WSAGetLastError();
        CUIHandler::Msg("Could not create inet socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
		return retCode;
	}

	// Bind the socket to the address returned
	retCode = bind(serverSocket, (LPSOCKADDR)&sin, sizeof(sin));
	if(retCode == SOCKET_ERROR)
	{
        retCode = WSAGetLastError();
		CUIHandler::Msg("Could not bind inet socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
		return retCode;
	}
	if(listen(serverSocket, SOMAXCONN) == SOCKET_ERROR)
    {
        retCode = WSAGetLastError();
        CUIHandler::Msg("Could not listen on inet socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
        return retCode;
    }

	return 0;
}

int CCommHandler::StartBtServer()
{
	int retCode = 0;
    WSAQUERYSET wsaQuerySet = {0};
    SOCKADDR_BTH sockAddrBthLocal = {0};
	int iAddrLen = sizeof(SOCKADDR_BTH);
	CSADDR_INFO csAddrInfo = {0};

    // Open a bluetooth socket using RFCOMM protocol
    if((serverSocket = socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM)) == INVALID_SOCKET)
    {
        retCode = WSAGetLastError();
        CUIHandler::Msg("Could not create bluetooth socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
        return retCode;
    }
	// Setting address family to AF_BTH indicates winsock2 to use Bluetooth port
    sockAddrBthLocal.addressFamily = AF_BTH;
    sockAddrBthLocal.port = BT_PORT_ANY;

    // bind() associates a local address and port combination
    // with the socket just created. This is most useful when
    // the application is a server that has a well-known port
    // that clients know about in advance.
    if(bind(serverSocket, (struct sockaddr *) &sockAddrBthLocal, sizeof(SOCKADDR_BTH)) == SOCKET_ERROR)
    {
        retCode = WSAGetLastError();
        CUIHandler::Msg("Could not bind bluetooth socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
        return retCode;
    }

    if(getsockname(serverSocket, (struct sockaddr *)&sockAddrBthLocal, &iAddrLen) == SOCKET_ERROR)
    {
        retCode = WSAGetLastError();
        CUIHandler::Msg("Could not access bluetooth socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
        return retCode;
    }

    // CSADDR_INFO
    csAddrInfo.LocalAddr.iSockaddrLength = sizeof( SOCKADDR_BTH );
    csAddrInfo.LocalAddr.lpSockaddr = (LPSOCKADDR)&sockAddrBthLocal;
    csAddrInfo.RemoteAddr.iSockaddrLength = sizeof( SOCKADDR_BTH );
    csAddrInfo.RemoteAddr.lpSockaddr = (LPSOCKADDR)&sockAddrBthLocal;
    csAddrInfo.iSocketType = SOCK_STREAM;
    csAddrInfo.iProtocol = BTHPROTO_RFCOMM;

    // If we got an address, go ahead and advertise it.
    ZeroMemory(&wsaQuerySet, sizeof(WSAQUERYSET));
    wsaQuerySet.dwSize = sizeof(WSAQUERYSET);
    wsaQuerySet.lpServiceClassId = (LPGUID) &g_guidServiceClass;
    wsaQuerySet.lpszServiceInstanceName = "SmartCam Server";
    wsaQuerySet.lpszComment = "Webcam over bluetooth";
    wsaQuerySet.dwNameSpace = NS_BTH;
    wsaQuerySet.dwNumberOfCsAddrs = 1;     // Must be 1.
    wsaQuerySet.lpcsaBuffer = &csAddrInfo; // Required.

    // As long as we use a blocking accept(), we will have a race
    // between advertising the service and actually being ready to
    // accept connections.  If we use non-blocking accept, advertise
    // the service after accept has been called.
    if(WSASetService(&wsaQuerySet, RNRSERVICE_REGISTER, 0) == SOCKET_ERROR)
    {
        retCode = WSAGetLastError();
        CUIHandler::Msg("Could not set service on bluetooth socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
        return retCode;
    }

    // listen() call indicates winsock2 to listen on a given socket for any incoming connection.
    if(listen(serverSocket, SOMAXCONN) == SOCKET_ERROR)
    {
        retCode = WSAGetLastError();
        CUIHandler::Msg("Could not listen on bluetooth socket: %d\n(%s)", retCode, Util::GetLastErrorMessage());
        return retCode;
    }
	return 0;
}

int CCommHandler::AcceptClient()
{
	// accept() call indicates winsock2 to wait for any
	// incoming connection request from a remote socket.
	// If there are already some connection requests on the queue,
	// then accept() extracts the first request and creates a new socket and
	// returns the handle to this newly created socket. This newly created
	// socket represents the actual connection that connects the two sockets.
	if((clientSocket = accept(serverSocket, NULL, NULL)) == INVALID_SOCKET)
	{
        int retCode = WSAGetLastError();
        string msg = string("Could not accept connection on socket: ") + Util::GetLastErrorMessage();
        OutputDebugString(msg.c_str());
        return retCode;
	}
    isConnected = TRUE;
    pSmartEngine->OnConnected();
	return 0;
}

int CCommHandler::Disconnect()
{
    isConnected = FALSE;
	// close the sockets (if opened)
    if(clientSocket != INVALID_SOCKET)
    {
		if(closesocket(clientSocket) == SOCKET_ERROR)
		{
			string msg = string("closesocket(clientSocket) < Cleanup > failed : ") + Util::GetLastErrorMessage();
			OutputDebugString(msg.c_str());
            return WSAGetLastError();
		}
        clientSocket = INVALID_SOCKET;
    }
    return 0;
}

int CCommHandler::RcvPacket()
{
	int retCode = 0;
	unsigned char header[4] = {0};

	retCode = recv(clientSocket, (char*) header, 4, 0);
	if((retCode == 0) || (retCode == WSAECONNRESET) || (retCode == SOCKET_ERROR))
	{
		Disconnect();
		pSmartEngine->OnDisconnected();
		return -1;
	}

	rcvPacketType = (SmartCamPacketType) (header[0]);
    rcvPacketLen = ((UINT32)header[1] << 16) | ((UINT32)header[2] << 8) | ((UINT32)header[3]);
    if(rcvPacketMaxLen < rcvPacketLen)
    {
        delete[] rcvPacket;
        rcvPacketMaxLen = rcvPacketLen + rcvPacketLen/3;
        rcvPacket = new BYTE[rcvPacketMaxLen];
    }

	int rcvdBytesCount = 0;
	while(rcvdBytesCount < rcvPacketLen)
	{
		retCode = recv(clientSocket, ((char*) rcvPacket) + rcvdBytesCount, rcvPacketLen - rcvdBytesCount, 0);
		// Connection closed or socket error
		if((retCode == 0) || (retCode == WSAECONNRESET) || (retCode == SOCKET_ERROR))
		{
			Disconnect();
			pSmartEngine->OnDisconnected();
			return -1;
		}
		// All went well, advance the byte count
		else
		{
			rcvdBytesCount += retCode;
		}
	}

	return 0;
}

void CCommHandler::StopServer()
{
    // close the sockets (if opened)
    if(clientSocket != INVALID_SOCKET)
    {
		if(closesocket(clientSocket) == SOCKET_ERROR)
		{
			string msg = string("closesocket(clientSocket) < Cleanup > failed : ") + Util::GetLastErrorMessage();
			OutputDebugString(msg.c_str());
		}
        clientSocket = INVALID_SOCKET;
    }
    if(serverSocket != INVALID_SOCKET)
    {
		if(closesocket(serverSocket) == SOCKET_ERROR)
		{
			string msg = string("closesocket(serverSocket) < Cleanup > failed : ") + Util::GetLastErrorMessage();
			OutputDebugString(msg.c_str());
		}
        serverSocket = INVALID_SOCKET;
    }
}

void CCommHandler::Cleanup()
{
    StopServer();
	// finish with winsock2
	WSACleanup();
    if(rcvPacket != NULL)
    {
        delete[] rcvPacket;
        rcvPacket = NULL;
    }
    rcvPacketLen = 0;
    rcvPacketMaxLen = 0;
}

BOOL CCommHandler::IsConnected()
{
    return isConnected;
}

BYTE* CCommHandler::GetRcvPacket()
{
    return rcvPacket;
}

UINT32 CCommHandler::GetRcvPacketLen()
{
    return rcvPacketLen;
}

SmartCamPacketType CCommHandler::GetRcvPacketType()
{
    return rcvPacketType;
}
