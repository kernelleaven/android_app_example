/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// SmartCam.cpp

#include "StdAfx.h"

#include "SmartEngine.h"
#include "resource.h"

CSmartEngine* g_pEngine = NULL;

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable = NULL;
    int result = 0;
	// Create the engine object
    g_pEngine = new CSmartEngine(hInstance);

    result = g_pEngine->Initialize();
    if(result != 0)
    {
        g_pEngine->Cleanup();
        delete g_pEngine;
        return -1;
    }

    result = g_pEngine->StartUI(nCmdShow);
    if(result != 0)
    {
        g_pEngine->Cleanup();
        delete g_pEngine;
        return -1;
    }

    result = g_pEngine->StartCommThread();
    if(result != 0)
    {
        g_pEngine->Cleanup();
        delete g_pEngine;
        return -1;
    }

    hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_SMARTCAM);
	// Main message loop:
	while(GetMessage(&msg, NULL, 0, 0)) 
	{
		if(!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
    delete g_pEngine;
    return (int) msg.wParam;
}

void Cleanup()
{
    g_pEngine->StopCommThread();
    g_pEngine->Cleanup();
}
