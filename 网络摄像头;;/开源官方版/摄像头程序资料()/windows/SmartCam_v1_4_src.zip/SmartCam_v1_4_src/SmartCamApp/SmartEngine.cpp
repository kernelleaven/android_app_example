/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// SmartEngine.cpp

#include "StdAfx.h"

#include "SmartEngine.h"
#include "CommHandler.h"
#include "UIHandler.h"
#include "DShowHandler.h"
#include "JpegHandler.h"

#pragma comment(linker, "\"/manifestdependency:type='Win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")

#pragma data_seg ("InstanceControl")
LONG  gFirstInstMainHWnd = 0;
#pragma data_seg ()
#pragma comment (linker, "/SECTION:InstanceControl,RWS")

CSmartEngine::CSmartEngine(HINSTANCE hInst):
	hSingleInstSem(NULL),
    gdiplusToken(0),
    pSharedMem(NULL),
    hFileMapping(NULL),
    pSharedMemBmp(NULL),
    frameNumber(0),
	crtWidth(-1),
	crtHeight(-1),
    lastSampleTimeMillis(0),
    crtSampleFrames(0),
    isAlive(FALSE),
    hCommThread(NULL),
    pCommHandler(NULL),
    pJpegHandler(NULL),
    pUIHandler(NULL),
	pDShowHandler(NULL),
    hInstance(NULL),
    crtSettings()
{
    hInstance = hInst;
}

CSmartEngine::~CSmartEngine()
{
    if(pCommHandler != NULL)
    {
        delete pCommHandler;
        pCommHandler = NULL;
    }
    if(pJpegHandler != NULL)
    {
        delete pJpegHandler;
        pJpegHandler = NULL;
    }
    if(pUIHandler != NULL)
    {
        delete pUIHandler;
        pUIHandler = NULL;
    }
	if(pDShowHandler != NULL)
	{
		delete pDShowHandler;
		pDShowHandler = NULL;
	}
}

int CSmartEngine::Initialize()
{
	// First see if this is the first instance of the application
	hSingleInstSem = CreateSemaphore(NULL, 0, 1, SMARTCAM_CLASSNAME);
	DWORD err = GetLastError();
	if(err == ERROR_ALREADY_EXISTS)
	{
		// not the first instance, bring the existing app to the foreground and exit this instance
		if(gFirstInstMainHWnd != 0 && IsWindow((HWND) gFirstInstMainHWnd))
		{
			// first attempt to restore (in case it's minimized)
			ShowWindow((HWND) gFirstInstMainHWnd, SW_RESTORE);
            // then bring to foreground
            SetForegroundWindow((HWND)gFirstInstMainHWnd);
		}
		return -1;
	}
	// Initialize GDI+
	GdiplusStartupInput gdiplusStartupInput;
	if(GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL) != Ok)
	{
        CUIHandler::Msg("Could not initialize GDI+");   
		return -1;
	}

    int result = AllocMem();
    if(result != 0)
    {
        return result;
    }

    pUIHandler = new CUIHandler(this, hInstance);
    result = pUIHandler->Initialize();
    if(result != 0)
        return result;

	pDShowHandler = new CDShowHandler(this);
    result = pDShowHandler->Initialize();
    if(result != 0)
        return result;

    pCommHandler = new CCommHandler(this);
    result = pCommHandler->Initialize();
    if(result != 0)
        return result;

    pJpegHandler = new CJpegHandler();

    crtSettings = CUserSettings::LoadSettings();
    ShareFrame(pUIHandler->GetLogoBmp(), 0);
    return 0;
}

void CSmartEngine::Cleanup()
{
	CloseHandle(hSingleInstSem);
	hSingleInstSem = NULL;
	if(pUIHandler != NULL)
		ShareFrame(pUIHandler->GetLogoBmp(), SC_END_OF_STREAM);
    if(pCommHandler != NULL)
        pCommHandler->Cleanup();
    if(pUIHandler != NULL)
        pUIHandler->Cleanup();
	if(pDShowHandler != NULL)
		pDShowHandler->Cleanup();
    FreeMem();
    // Release GDI+
    GdiplusShutdown(gdiplusToken);
}

int CSmartEngine::StartUI(int nCmdShow)
{
    int result = 0;
    result = pUIHandler->CreateMainWnd(nCmdShow);
	if(result == 0)
		gFirstInstMainHWnd = (LONG) pUIHandler->GetHWNDMainWnd();
    return result;
}

DWORD WINAPI CSmartEngine::CommThreadProc(LPVOID lpParam)
{
	int errCode = 0;
	CSmartEngine* engine = (CSmartEngine*) lpParam;
	errCode = engine->StartServer();
    if(errCode)
    {
        engine->pUIHandler->UpdateOnNoNetwork();
        while(errCode != 0)
        {
            Sleep(1000);
            errCode = engine->StartServer();
        }
    }
	engine->pUIHandler->UpdateOnDisconnected();
	engine->AcceptClient();
	while(engine->isAlive)
	{
		errCode = engine->RcvPacket();
		if(errCode == 0)	// SUCCESS
		{
			engine->ProcessPacket();
		}
		else				// ERROR
		{
			engine->AcceptClient();
		}
	}
	return 0;
}

int CSmartEngine::StartCommThread()
{
	// Create the comm thread
	isAlive = TRUE;
	DWORD commThreadId = 0;
	hCommThread = CreateThread(
                        NULL,               // default security attributes
                        0,                  // use default stack size
                        CommThreadProc,     // thread function
                        this,               // argument to thread function
                        0,                  // use default creation flags
                        &commThreadId);     // returns the thread identifier
	if(hCommThread == NULL)
    {
        CUIHandler::Msg("Could not start the communication thread: %d\n(%s)", WSAGetLastError(), Util::GetLastErrorMessage());
		return -1;
    }
	return 0;
}

void CSmartEngine::StopCommThread()
{
    if(hCommThread == NULL)
        return;
	//wait a reasonable length of time for the comm thread to quit.
    isAlive = FALSE;
    WaitForSingleObject(hCommThread, 300);
	TerminateThread(hCommThread, 0);
    CloseHandle(hCommThread);
    hCommThread = NULL;
    pCommHandler->StopServer();
}

int CSmartEngine::Disconnect()
{
    return pCommHandler->Disconnect();
}

HINSTANCE CSmartEngine::GetHInstance()
{
    return hInstance;
}

HWND CSmartEngine::GetHWNDMainWnd()
{
    return pUIHandler->GetHWNDMainWnd();
}

HBITMAP CSmartEngine::GetHBITMAPLogo()
{
    return pUIHandler->GetHBITMAPLogo();
}

Bitmap* CSmartEngine::GetLogoBmp()
{
    return pUIHandler->GetLogoBmp();
}

WNDPROC CSmartEngine::GetOrigVideoWndProc()
{
    return pUIHandler->GetOrigVideoWndProc();
}

BOOL CSmartEngine::IsConnected()
{
    return pCommHandler->IsConnected();
}

BOOL CSmartEngine::IsCaptureStarted()
{
    return FALSE;
}

void CSmartEngine::HandleGraphEvent()
{
}

int CSmartEngine::AllocMem()
{
    HRESULT hr = NULL;
	// Create the shared memory to store the received bitmap frames
	if(!Util::CreateSharedMem(&hFileMapping, &pSharedMem))
	{
        CUIHandler::Msg("Could not create shared memory\n");
        FreeMem();
		return GetLastError();
	}

    // Create the shared memory mapped bitmap
	pSharedMemBmp = new Bitmap(FRAME_WIDTH, FRAME_HEIGHT, FRAME_WIDTH * 3, 
						       PixelFormat24bppRGB, (BYTE*) pSharedMem + FRAME_NUMBER_SIZE);
	frameNumber = 0;
	return 0;
}

void CSmartEngine::FreeMem()
{
	// Close the shared memory
	// Delete the shared memory mapped bitmap
    if(pSharedMemBmp != NULL)
    {
	    delete pSharedMemBmp;
        pSharedMem = NULL;
    }
	// Unmap shared memory from the process's address space.
    if(pSharedMem != NULL)
    {
	    UnmapViewOfFile(pSharedMem);
        pSharedMem = NULL;
    }
	// Close the process's handle to the file-mapping object.
    if(hFileMapping != NULL)
    {
	    CloseHandle(hFileMapping);
        hFileMapping = NULL;
    }
}

int CSmartEngine::StartServer()
{
    int result = 0;
    if(crtSettings.connectionType == CONN_INET)
        result = pCommHandler->StartInetServer(crtSettings.inetPort);
    else if(crtSettings.connectionType == CONN_BLUETOOTH)
        result = pCommHandler->StartBtServer();
    return result;
}

void CSmartEngine::AcceptClient()
{
    if(pCommHandler->AcceptClient() != 0)
        ExitApp();
}

int CSmartEngine::RcvPacket()
{
    return pCommHandler->RcvPacket();
}

void CSmartEngine::ProcessPacket()
{
    if(pCommHandler->GetRcvPacketType() == PACKET_JPEG_HEDAER)
        pJpegHandler->decodeHeader(pCommHandler->GetRcvPacket(), pCommHandler->GetRcvPacketLen());
    else if(pCommHandler->GetRcvPacketType() == PACKET_JPEG_DATA)
    {
        int w = 0, h = 0;
        BYTE* rgb24 = pJpegHandler->decodeRGB24(pCommHandler->GetRcvPacket(), pCommHandler->GetRcvPacketLen(), w, h);
		// Put the decompressed bitmap frame in the shared memory and update the preview window
        Bitmap bmpFrame(w, h, w*3, PixelFormat24bppRGB, rgb24);
		ShareFrame(&bmpFrame);
		PreviewFrame(&bmpFrame);
        SampleFPS();

		// Update resolution status bar message
		if(crtWidth != w || crtHeight != h)
		{
			crtWidth = w;
			crtHeight = h;
			pUIHandler->UpdateResolution(crtWidth, crtHeight);
		}
    }
}

void CSmartEngine::ShareFrame(Bitmap* bmpFrame)
{
	++frameNumber;
	ShareFrame(bmpFrame, frameNumber);
}

void CSmartEngine::ShareFrame(Bitmap* bmpFrame, int frameNo)
{
    // Copy the received bitmap frame in the shared memory
    // Create a GDI+ graphics object to manage the drawing on the shared memory bitmap.
    Graphics g(pSharedMemBmp);
    // GDI+ is top-down by default, so we need to set a transform on the Graphics object to flip the image.
	// Flip the image around the X axis.
    g.ScaleTransform(1.0, -1.0);
	// Move it back into place.
	g.TranslateTransform(0, (float)FRAME_HEIGHT, MatrixOrderAppend);
	// Draw the frame to share on top the shared memory buffer
	Status st = g.DrawImage(bmpFrame, 0, 0, FRAME_WIDTH, FRAME_HEIGHT);
	char* xx = Util::GetLastErrorMessage();

    *((int*) pSharedMem) = frameNo;
}

void CSmartEngine::PreviewFrame(Bitmap* bmpFrame)
{
    // Draw the received bitmap frame in the preview window
    HDC hdcVideoWnd = GetDC(pUIHandler->GetHWNDVideoWnd());
	Graphics graphics(hdcVideoWnd);
	RECT rc;
	GetClientRect(pUIHandler->GetHWNDVideoWnd(), &rc);
	graphics.DrawImage(bmpFrame, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
	ReleaseDC(pUIHandler->GetHWNDVideoWnd(), hdcVideoWnd);
}

void CSmartEngine::SampleFPS()
{
	unsigned long nowMillis = GetCurrentTime();
	unsigned long elapsedMillis = nowMillis - lastSampleTimeMillis;
	if(elapsedMillis >= 1000)
	{
		float fps = ((float)crtSampleFrames * 1000)/elapsedMillis;
		char fps_str[30];
		memset(fps_str, 0, 30);
		sprintf(fps_str, "FPS: %.2f", fps);
        pUIHandler->UpdateFPS(fps_str);
		lastSampleTimeMillis = nowMillis;
		crtSampleFrames = 0;
	}
    else
    {
        ++crtSampleFrames;
    }
}

void CSmartEngine::OnConnected()
{
    pUIHandler->UpdateOnConnected();
}

void CSmartEngine::OnDisconnected()
{
    crtWidth = -1;
    crtHeight = -1;
    ShareFrame(pUIHandler->GetLogoBmp(), SC_STREAM_DISCONNECTED);
    pUIHandler->UpdateOnDisconnected();
}

void CSmartEngine::ExitApp()
{
    SendMessage(pUIHandler->GetHWNDMainWnd(), WM_DESTROY, (WPARAM) 0, (LPARAM) 0);
}

CUserSettings CSmartEngine::GetSettings()
{
    return crtSettings;
}

void CSmartEngine::SaveSettings(CUserSettings settings)
{
    if((crtSettings.connectionType != settings.connectionType) ||
       (crtSettings.inetPort != settings.inetPort) ||
       (crtSettings.videoCodec != settings.videoCodec))
    {
        CUserSettings::SaveSettings(settings);
		CUserSettings oldSettings = crtSettings;
		crtSettings = settings;
        if((oldSettings.connectionType != settings.connectionType) ||
           (oldSettings.inetPort != settings.inetPort))
        {
            pUIHandler->UpdateStatusBarIcon();
            StopCommThread();
            StartCommThread();
        }
    }
}

BOOL CSmartEngine::IsDivXCodecInstalled()
{
	return pDShowHandler->IsDivXCodecInstalled();
}

BOOL CSmartEngine::IsCinepakCodecInstalled()
{
	return pDShowHandler->IsCinepakCodecInstalled();
}

void CSmartEngine::StartFileCapture()
{
	if(!pUIHandler->OpenFileDialog(captureFileName, CAPTURE_FILE_NAME_MAX_LEN))
		return;
	if(!DeleteFile(captureFileName))
	{
		DWORD result = GetLastError();
		if(result != ERROR_FILE_NOT_FOUND)
		{
			CUIHandler::Msg("The selected file is in use and can not be replaced");
			return;
		}
	}

	if(pDShowHandler->StartFileCapture(captureFileName) == 0)
		pUIHandler->UpdateOnCaptureStarted();
}

void CSmartEngine::StopFileCapture()
{
	pDShowHandler->StopFileCapture();
	pUIHandler->UpdateOnCaptureStopped();
}
