/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// CommHandler.h

#ifndef __COMM_HANDLER_H__
#define __COMM_HANDLER_H__

#include <Winsock2.h>
#include <Ws2bth.h>

class CSmartEngine;

typedef enum SmartCamPacketType {
    PACKET_JPEG_HEDAER = 0,
    PACKET_JPEG_DATA = 1
} SmartCamPacketType;

#define DEFAULT_PAKET_MAX_LEN 4096

class CCommHandler
{
public:
	CCommHandler(CSmartEngine* pSmartEngine);
	virtual ~CCommHandler();
	int Initialize();
	void Cleanup();
	int StartInetServer(int port);
    int StartBtServer();
    void StopServer();
	int AcceptClient();
    int Disconnect();
	int RcvPacket();
    void OnConnected();
    BOOL IsConnected();
    BYTE* GetRcvPacket();
    UINT32 GetRcvPacketLen();
    SmartCamPacketType GetRcvPacketType();

private:
	// Methods:
	int InitWinSock2();

	// Data:
    CSmartEngine* pSmartEngine;
    bool isConnected;
	// BT sockets
	SOCKET serverSocket;
	SOCKET clientSocket;

    BYTE* rcvPacket;
    UINT32 rcvPacketLen;
    UINT32 rcvPacketMaxLen;
    SmartCamPacketType rcvPacketType;
};

#endif//__COMM_HANDLER_H__
