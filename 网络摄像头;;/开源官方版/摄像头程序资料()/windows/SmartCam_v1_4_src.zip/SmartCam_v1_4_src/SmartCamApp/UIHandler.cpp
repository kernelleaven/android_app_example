/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// UIHandler.cpp
#include <Commdlg.h>
#include "StdAfx.h"
#include "UIHandler.h"

#include "SmartCam.h"           // g_pEngine
#include "SmartEngine.h"
#include "DShowHandler.h"       // WM_GRAPHNOTIFY

// Main window procedure
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    switch (message)
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam);
            wmEvent = HIWORD(wParam);
            // Parse the menu selections:
            switch(wmId)
            {
                case IDM_ABOUT:
                    DialogBox(g_pEngine->GetHInstance(), (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
                    break;
                case IDM_EXIT:
                    DestroyWindow(hWnd);
                    break;
                case IDM_SETTINGS:
                    DialogBox(g_pEngine->GetHInstance(), (LPCTSTR)IDD_SETTINGS, hWnd, (DLGPROC)SettingsDlgProc);
                    break;
                case IDM_START_CAPTURE:
					g_pEngine->StartFileCapture();
                    break;
                case IDM_STOP_CAPTURE:
	                g_pEngine->StopFileCapture();
                    break;
                case IDM_DISCONNECT:
                    g_pEngine->Disconnect();
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case CUIHandler::APPWM_TRAYICON:
            switch(lParam)
            {
                //case WM_RBUTTONUP:
                case WM_LBUTTONDBLCLK:
                    ShowWindow(hWnd, SW_RESTORE);
                    SetForegroundWindow(hWnd);
                    break;
            }
            break;
        case WM_SIZE:
            if(IsIconic(hWnd))
            {
                ShowWindow(hWnd, SW_HIDE);
            }
            break;
        case WM_DESTROY:
            // cleanup code
            Cleanup();
            PostQuitMessage(0);
            break;
        case CDShowHandler::WM_GRAPHNOTIFY:
             g_pEngine->HandleGraphEvent();
             break;
        case WM_NOTIFY:
            switch (((LPNMHDR) lParam)->code)
            {
                case TTN_GETDISPINFO:
                    {
                    LPTOOLTIPTEXT lpttt;

                    lpttt = (LPTOOLTIPTEXT) lParam;
                    lpttt->hinst = g_pEngine->GetHInstance();

                    // Specify the resource identifier of the descriptive text for the given button.
                    switch (lpttt->hdr.idFrom)
                    {
                        case IDM_SETTINGS:
                            lpttt->lpszText = MAKEINTRESOURCE(IDS_TTIP_SETTINGS);
                            break;

                        case IDM_START_CAPTURE:
                            lpttt->lpszText = MAKEINTRESOURCE(IDS_TTIP_START_CAPTURE);
                            break;
                        case IDM_STOP_CAPTURE:
                            lpttt->lpszText = MAKEINTRESOURCE(IDS_TTIP_STOP_CAPTURE);
                            break;
                        case IDM_DISCONNECT:
                            lpttt->lpszText = MAKEINTRESOURCE(IDS_TTIP_DISCONNECT);
                            break;
                    }
                    break;
                    }
                default:
                    break;
            }

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_INITDIALOG:
        CUIHandler::CenterWindow(hDlg, g_pEngine->GetHWNDMainWnd());
        return TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
        {
            EndDialog(hDlg, LOWORD(wParam));
            return TRUE;
        }
        break;
    }
    return FALSE;
}

// Message handler for the settings dialog box.
LRESULT CALLBACK SettingsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static CUserSettings settings;
    char port_str[10] = {0};
	BOOL isCinepakInstalled = FALSE;
	BOOL isDivXInstalled = FALSE;

    switch (message)
    {
    case WM_INITDIALOG:
        // Populate the settings dialog
        settings = g_pEngine->GetSettings();

		isCinepakInstalled = g_pEngine->IsCinepakCodecInstalled();
		isDivXInstalled = g_pEngine->IsDivXCodecInstalled();

		EnableWindow(GetDlgItem(hDlg, IDC_CODEC_CINEPAK), isCinepakInstalled);
        EnableWindow(GetDlgItem(hDlg, IDC_CODEC_DIVX), isDivXInstalled);

		if(!isCinepakInstalled)
		{
			SetWindowText(GetDlgItem(hDlg, IDC_CODEC_CINEPAK), "Cinepak Codec (not installed...)");
			if(settings.videoCodec == CODEC_CINEPAK)
			{
				settings.videoCodec = CODEC_NONE;
				g_pEngine->SaveSettings(settings);
			}
		}
		else
		{
			SetWindowText(GetDlgItem(hDlg, IDC_CODEC_CINEPAK), "Cinepak Codec");
		}

		if(!isDivXInstalled)
		{
			SetWindowText(GetDlgItem(hDlg, IDC_CODEC_DIVX), "DivX (not installed...)");
			if(settings.videoCodec == CODEC_DIVX)
			{
				settings.videoCodec = CODEC_NONE;
				g_pEngine->SaveSettings(settings);
			}
		}
		else
		{
			SetWindowText(GetDlgItem(hDlg, IDC_CODEC_DIVX), "DivX");
		}

        sprintf(port_str, "%d", settings.inetPort);
        CheckRadioButton(hDlg, IDC_RB_BLUETOOTH, IDC_RB_INET, settings.connectionType + IDC_RB_BLUETOOTH);
        SetWindowText(GetDlgItem(hDlg, IDC_EDIT_PORT), port_str);
        if(g_pEngine->IsConnected())
        {
            EnableWindow(GetDlgItem(hDlg, IDC_RB_BLUETOOTH), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_RB_INET), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_STATIC_PORT), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PORT), FALSE);
        }
        else
        {
            EnableWindow(GetDlgItem(hDlg, IDC_STATIC_PORT), settings.connectionType == CONN_INET);
            EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PORT), settings.connectionType == CONN_INET);
        }
        CheckRadioButton(hDlg, IDC_CODEC_NONE, IDC_CODEC_DIVX, settings.videoCodec + IDC_CODEC_NONE);
        if(g_pEngine->IsCaptureStarted())
        {
            EnableWindow(GetDlgItem(hDlg, IDC_CODEC_NONE), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_CODEC_CINEPAK), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_CODEC_DIVX), FALSE);
        }

        CUIHandler::CenterWindow(hDlg, g_pEngine->GetHWNDMainWnd());
        return TRUE;

    case WM_COMMAND:
        switch(LOWORD(wParam)) 
        {
            case IDC_RB_BLUETOOTH:
                if(IsDlgButtonChecked(hDlg, IDC_RB_BLUETOOTH))
                {
                    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_PORT), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PORT), FALSE);
                    sprintf(port_str, "%d", settings.inetPort);
                    SetWindowText(GetDlgItem(hDlg, IDC_EDIT_PORT), port_str);
                }
                break;
            case IDC_RB_INET:
                if(IsDlgButtonChecked(hDlg, IDC_RB_INET))
                {
                    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_PORT), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PORT), TRUE);
                }
                break;
            case IDOK:
                GetWindowText(GetDlgItem(hDlg, IDC_EDIT_PORT), port_str, sizeof(port_str));
                sscanf(port_str, "%d", &settings.inetPort);

                if(IsDlgButtonChecked(hDlg, IDC_RB_BLUETOOTH) == BST_CHECKED)
                    settings.connectionType = CONN_BLUETOOTH;
                else if(IsDlgButtonChecked(hDlg, IDC_RB_INET) == BST_CHECKED)
                    settings.connectionType = CONN_INET;

                if(IsDlgButtonChecked(hDlg, IDC_CODEC_NONE) == BST_CHECKED)
                    settings.videoCodec = CODEC_NONE;
                else if(IsDlgButtonChecked(hDlg, IDC_CODEC_CINEPAK) == BST_CHECKED)
                    settings.videoCodec = CODEC_CINEPAK;
                else if(IsDlgButtonChecked(hDlg, IDC_CODEC_DIVX) == BST_CHECKED)
                    settings.videoCodec = CODEC_DIVX;
                g_pEngine->SaveSettings(settings);
                // Fall through
            case IDCANCEL:
                // Destroy the dialog box.
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
        }
        break;
    default:
        return FALSE;
    }
    return FALSE;
}

LRESULT CALLBACK VideoWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    HDC hdc, hdcMem;
    PAINTSTRUCT ps;
    switch(message)
    {
    case WM_PAINT:
        if(g_pEngine != NULL && !g_pEngine->IsConnected())
        {
            InvalidateRect(hwnd, NULL, TRUE);
            hdc = BeginPaint(hwnd, &ps);
            RECT rc;
            GetClientRect(hwnd, &rc);
            hdcMem = CreateCompatibleDC(hdc);
            SelectObject(hdcMem, g_pEngine->GetHBITMAPLogo());
            StretchBlt(hdc, 0, 0, rc.right - rc.left, rc.bottom - rc.top, 
                       hdcMem, 0, 0, g_pEngine->GetLogoBmp()->GetWidth(), 
                       g_pEngine->GetLogoBmp()->GetHeight(), SRCCOPY);
            DeleteDC(hdcMem);
            ps.fErase = TRUE;
            EndPaint(hwnd, &ps);
        }
        break;
    case WM_DESTROY:
        SetWindowLong(hwnd, GWL_WNDPROC, (LONG)g_pEngine->GetOrigVideoWndProc());
        break;
    }
    return CallWindowProc(g_pEngine->GetOrigVideoWndProc(), hwnd, message, wParam, lParam); 
}

const char* CUIHandler::TRAY_TOOLTIP_CONNECTED = "SmartCam - Connected";
const char* CUIHandler::TRAY_TOOLTIP_DISCONNECTED = "SmartCam - Disconnected";
const char* CUIHandler::TRAY_TOOLTIP_NO_NETWORK = "SmartCam - No available network";

const TBBUTTON CUIHandler::tbButtons[NUM_TBAR_BUTTONS] = {
    {
        0, //iBitmap
        IDM_SETTINGS,//idCommand;
        TBSTATE_ENABLED,//fsState
        BTNS_BUTTON|BTNS_AUTOSIZE,//fsStyle
        0,//dwData
        NULL//iString
    },
    {
        I_IMAGENONE, //iBitmap
        0,//idCommand;
        TBSTATE_ENABLED,//fsState
        TBSTYLE_SEP,//fsStyle
        0,//dwData
        NULL//iString
    },
    {
        1, //iBitmap
        IDM_START_CAPTURE,//idCommand;
        TBSTATE_ENABLED,//fsState
        BTNS_BUTTON|BTNS_AUTOSIZE,//fsStyle
        0,//dwData
        NULL//iString
    },
    {
        2, //iBitmap
        IDM_STOP_CAPTURE,//idCommand;
        TBSTATE_ENABLED,//fsState
        BTNS_BUTTON|BTNS_AUTOSIZE,//fsStyle
        0,//dwData
        NULL//iString
    },
    {
        I_IMAGENONE, //iBitmap
        0,//idCommand;
        TBSTATE_ENABLED,//fsState
        TBSTYLE_SEP,//fsStyle
        0,//dwData
        NULL//iString
    },
    {
        3, //iBitmap
        IDM_DISCONNECT,//idCommand;
        TBSTATE_ENABLED,//fsState
        BTNS_BUTTON|BTNS_AUTOSIZE,//fsStyle
        0,//dwData
        NULL//iString
    }
};

void CUIHandler::RegisterMainWndClass()
{
    WNDCLASSEX wclx;
    memset(&wclx, 0, sizeof(wclx));

    wclx.cbSize = sizeof(WNDCLASSEX);
    wclx.style = CS_HREDRAW | CS_VREDRAW;
    wclx.lpfnWndProc = WndProc;
    wclx.cbClsExtra = 0;
    wclx.cbWndExtra = 0;
    wclx.hInstance = hInstance;
    wclx.hIcon = hIconConnected;
    wclx.hIconSm = hIconConnected;
    wclx.hCursor = LoadCursor(NULL, IDC_ARROW);
    wclx.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wclx.lpszMenuName = (LPCSTR)IDC_SMARTCAM;;
    wclx.lpszClassName = SMARTCAM_CLASSNAME;

    RegisterClassEx(&wclx);
}

void CUIHandler::UnregisterMainWndClass()
{
    UnregisterClass(SMARTCAM_CLASSNAME, hInstance);
}

void CUIHandler::CreateStatusBar()
{
    hStatusBarWnd = CreateWindowEx(0, STATUSCLASSNAME, (LPCTSTR) NULL, 
                                   WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, 
                                   hMainWnd, (HMENU) ID_STATUSBAR, hInstance, NULL);

    int statDims[3] = {100, 180, -1};
    SendMessage(hStatusBarWnd, SB_SETPARTS, (WPARAM) 3, (LPARAM) (LPINT)statDims);
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Disconnected");
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 1, (LPARAM) "FPS:");
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 2, (LPARAM) "Resolution:");
    UpdateStatusBarIcon();
}

void CUIHandler::CreateToolBar()
{
	hToolBarWnd = CreateWindowEx(0, TOOLBARCLASSNAME, (LPSTR) NULL, 
							    WS_CHILD | WS_VISIBLE | TBSTYLE_FLAT | TBSTYLE_TOOLTIPS | WS_BORDER,
							    0, 0, 0, 0,
							    hMainWnd, (HMENU) ID_TOOLBAR, hInstance, NULL);
	// Send the TB_BUTTONSTRUCTSIZE message, which is required for backward compatibility. 
	SendMessage(hToolBarWnd, TB_BUTTONSTRUCTSIZE, (WPARAM) sizeof(TBBUTTON), 0);

	// Create image list
	hTBarImgList = ImageList_Create(16, 16, ILC_COLOR32, 1, 0);
	HICON hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SETTINGS));
	ImageList_AddIcon(hTBarImgList, hicon);
	DestroyIcon(hicon);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_START_CAPTURE));
	ImageList_AddIcon(hTBarImgList, hicon);
	DestroyIcon(hicon);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_STOP_CAPTURE));
	ImageList_AddIcon(hTBarImgList, hicon);
    DestroyIcon(hicon);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_DISCONNECT));
	ImageList_AddIcon(hTBarImgList, hicon);
	DestroyIcon(hicon);
	// Create disabled image list
	hTBarDisabledImgList = ImageList_Create(16, 16, ILC_COLOR32, 1, 0);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SETTINGS));
	ImageList_AddIcon(hTBarDisabledImgList, hicon);
	DestroyIcon(hicon);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_START_CAPTURE_DISABLED));
	ImageList_AddIcon(hTBarDisabledImgList, hicon);
	DestroyIcon(hicon);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_STOP_CAPTURE_DISABLED));
	ImageList_AddIcon(hTBarDisabledImgList, hicon);
	DestroyIcon(hicon);
	hicon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_DISCONNECT_DISABLED));
	ImageList_AddIcon(hTBarDisabledImgList, hicon);
	DestroyIcon(hicon);

	SendMessage(hToolBarWnd, TB_SETIMAGELIST, (WPARAM) 0, (LPARAM) hTBarImgList);
	SendMessage(hToolBarWnd, TB_SETDISABLEDIMAGELIST, (WPARAM) 0, (LPARAM) hTBarDisabledImgList);
	SendMessage(hToolBarWnd, TB_ADDBUTTONS, (WPARAM) NUM_TBAR_BUTTONS, (LPARAM) (LPTBBUTTON) &tbButtons);
	SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_STOP_CAPTURE, (LPARAM) MAKELONG (FALSE, 0));
    SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_DISCONNECT, (LPARAM) MAKELONG (FALSE, 0));
	SendMessage(hToolBarWnd, TB_SETINDENT, 3, 0);
	SendMessage(hToolBarWnd, TB_AUTOSIZE, 0, 0);
	ShowWindow(hToolBarWnd, SW_SHOW);
}

void CUIHandler::CreateVideoWnd()
{
    RECT clientRect, statusRect, tbarRect;
    // Make the preview video fill our window
    GetClientRect(hMainWnd, &clientRect);
    GetWindowRect(hStatusBarWnd, &statusRect);
    GetWindowRect(hToolBarWnd, &tbarRect);
    int barsWidth = (statusRect.bottom - statusRect.top) + (tbarRect.bottom - tbarRect.top);
    int videoXpos = ((clientRect.right - clientRect.left) - VIDEO_WND_WIDTH)/2;
    int videoYpos = (tbarRect.bottom - tbarRect.top) + ((clientRect.bottom - clientRect.top) - barsWidth - VIDEO_WND_HEIGHT)/2;

    hVideoWnd = CreateWindowEx(0L, WC_STATIC, NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 
                               videoXpos, videoYpos, VIDEO_WND_WIDTH, VIDEO_WND_HEIGHT,
                               hMainWnd, (HMENU) NULL, hInstance, 0);
	wpOrigVideoWndProc = (WNDPROC) SetWindowLong(hVideoWnd, GWL_WNDPROC, (LONG) VideoWndProc);
	SendMessage(hVideoWnd, WM_PAINT, (WPARAM) 0, (LPARAM) 0);
}

BOOL CUIHandler::OpenFileDialog(char* fileName, int fileNameMaxLen)
{
    OPENFILENAME ofn;

    // Initialize OPENFILENAME
	ZeroMemory(fileName, fileNameMaxLen);
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hMainWnd;
    ofn.lpstrFile = fileName;
    ofn.nMaxFile = fileNameMaxLen;
    ofn.lpstrFilter = "Media files (*.avi)\0*.avi\0All files (*.*)\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrDefExt = "avi";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;

    // Display the Open dialog box. 
    BOOL result = GetSaveFileName(&ofn);
	return result;
}

void CUIHandler::UpdateOnCaptureStarted()
{
	SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_START_CAPTURE, (LPARAM) MAKELONG (FALSE, 0));
	//EnableMenuItem(GetMenu(hMainWnd), IDM_START_CAPTURE, MF_BYCOMMAND | MF_DISABLED);

	SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_STOP_CAPTURE, (LPARAM) MAKELONG (TRUE, 0));
	//EnableMenuItem(GetMenu(hMainWnd), IDM_STOP_CAPTURE, MF_BYCOMMAND | MF_ENABLED);
}

void CUIHandler::UpdateOnCaptureStopped()
{
	SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_START_CAPTURE, (LPARAM) MAKELONG (TRUE, 0));
	//EnableMenuItem(GetMenu(hMainWnd), IDM_START_CAPTURE, MF_BYCOMMAND | MF_ENABLED);

	SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_STOP_CAPTURE, (LPARAM) MAKELONG (FALSE, 0));
	//EnableMenuItem(GetMenu(hMainWnd), IDM_STOP_CAPTURE, MF_BYCOMMAND | MF_DISABLED);
}

void CUIHandler::CenterWindow(HWND hwndChild, HWND hwndParent)
{
    RECT rcChild, rcParent, rcWorkArea;
    // Get the height and width of the child window.
    GetWindowRect(hwndChild, &rcChild);
    int wChild = rcChild.right - rcChild.left;
    int hChild = rcChild.bottom - rcChild.top;

    // Get the height and width of the parent window.
    GetWindowRect(hwndParent, &rcParent);
    int wParent = rcParent.right - rcParent.left;
    int hParent = rcParent.bottom - rcParent.top;

    // Get the limits of the "work area".
    BOOL bResult = SystemParametersInfo(SPI_GETWORKAREA, sizeof(RECT), &rcWorkArea, 0);
    if(!bResult)
    {
        rcWorkArea.left = rcWorkArea.top = 0;
        rcWorkArea.right = GetSystemMetrics(SM_CXSCREEN);
        rcWorkArea.bottom = GetSystemMetrics(SM_CYSCREEN);
    }

    // Calculate new X position, then adjust for work area.
    int xNew = rcParent.left + ((wParent - wChild)/2);
    if(xNew < rcWorkArea.left)
        xNew = rcWorkArea.left;
    else if((xNew + wChild) > rcWorkArea.right)
        xNew = rcWorkArea.right - wChild;

    // Calculate new Y position, then adjust for work area.
    int yNew = rcParent.top  + ((hParent - hChild)/2);
    if(yNew < rcWorkArea.top)
        yNew = rcWorkArea.top;
    else if((yNew+hChild) > rcWorkArea.bottom)
        yNew = rcWorkArea.bottom - hChild;

    SetWindowPos (hwndChild, NULL, xNew, yNew, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

//  Create/modify the icon to the system tray.
void CUIHandler::CreateModifyTrayIcon(HICON hTrayIcon, const char* tooltip, BOOL create)
{
    NOTIFYICONDATA  nid;
    memset(&nid, 0, sizeof(nid));
    nid.cbSize = sizeof(nid);
    nid.hWnd = hMainWnd;
    nid.uID = ID_TRAYICON;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = APPWM_TRAYICON;
    nid.hIcon = hTrayIcon;
    strcpy(nid.szTip, tooltip);
    if(create)
        Shell_NotifyIcon(NIM_ADD, &nid);
    else
        Shell_NotifyIcon(NIM_MODIFY, &nid);
}

//  Removes the tray icon from the system tray.
void CUIHandler::RemoveTrayIcon()
{
    NOTIFYICONDATA nid;
    memset(&nid, 0, sizeof(nid));
    nid.cbSize = sizeof(nid);
    nid.hWnd = hMainWnd;
    nid.uID = ID_TRAYICON;
    Shell_NotifyIcon(NIM_DELETE, &nid);
}

void CUIHandler::LoadIcons()
{
	// Load the icons
    hIconConnected = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_CONNECTED));
    hIconDisconnected = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_DISCONNECTED));
    hIconNoNetwork = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_NO_NETWORK));
    hIconConnBt = (HICON)LoadImage(hInstance, MAKEINTRESOURCE(IDI_CONN_BT), IMAGE_ICON, 
                                   GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),
                                   LR_DEFAULTCOLOR | LR_SHARED);
    hIconConnInet = (HICON)LoadImage(hInstance, MAKEINTRESOURCE(IDI_CONN_INET), IMAGE_ICON, 
                                   GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),
                                   LR_DEFAULTCOLOR | LR_SHARED);

    // Load the application logo
    hLogoBmp = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BMP_LOGO));
    bmpLogo = new Bitmap(hInstance, (const WCHAR*)MAKEINTRESOURCE(IDB_BMP_LOGO));
}

void CUIHandler::DestroyIcons()
{
    DestroyIcon(hIconConnected);
    DestroyIcon(hIconDisconnected);
    DestroyIcon(hIconNoNetwork);
    DestroyIcon(hIconConnBt);
    DestroyIcon(hIconConnInet);
    DeleteObject(hLogoBmp);
    delete bmpLogo;
}

CUIHandler::CUIHandler(CSmartEngine* pEngine, HINSTANCE hInst):
    pSmartEngine(pEngine),
    hInstance(hInst),
    hMainWnd(NULL),
    hFont(NULL),
    hStatusBarWnd(NULL),
    hToolBarWnd(NULL),
    hVideoWnd(NULL),
    hTBarImgList(NULL),
    hTBarDisabledImgList(NULL),
    hIconConnected(NULL),
    hIconDisconnected(NULL),
    hIconNoNetwork(NULL),
    bmpLogo(NULL),
    hLogoBmp(NULL),
    wpOrigVideoWndProc(NULL)
{
}

CUIHandler::~CUIHandler()
{
    // No implementation required
}

int CUIHandler::Initialize()
{
    InitCommonControls();
    // Initialize COM
	HRESULT hResult = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    if(FAILED(hResult))
    {
		Msg("Could not initialize COM");   
		return -1;
    }
    LoadIcons();
    return 0;
}

int CUIHandler::CreateMainWnd(int nCmdShow)
{
    RegisterMainWndClass();
    hMainWnd = CreateWindow(SMARTCAM_CLASSNAME, SMARTCAM_CAPTION,
                            WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE,
                            CW_USEDEFAULT, 0, WND_WIDTH, WND_HEIGHT, NULL, NULL, hInstance, NULL);
    if(hMainWnd == NULL)
	{
		MessageBox(NULL, Util::GetLastErrorMessage(), "Error creating window", MB_OK | MB_ICONEXCLAMATION);
        return -1;
    }

    // Create font
    hFont = CreateFont(15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, VARIABLE_PITCH | FF_SWISS, "");
    SendMessage(hMainWnd, WM_SETFONT, (WPARAM) hFont, (LPARAM) TRUE);

    CreateModifyTrayIcon(hIconDisconnected, TRAY_TOOLTIP_DISCONNECTED, TRUE);

    // Create the status bar.
    CreateStatusBar();
    // Create the toolbar
    CreateToolBar();
    // Create the preview window
    CreateVideoWnd();

    ShowWindow(hMainWnd, nCmdShow);
    UpdateWindow(hMainWnd);
    return 0;
}

void CUIHandler::Cleanup()
{
    RemoveTrayIcon();
    ImageList_Destroy(hTBarImgList);
    ImageList_Destroy(hTBarDisabledImgList);
    DeleteFont(hFont);
    DestroyIcons();
}

HBITMAP CUIHandler::GetHBITMAPLogo()
{
    return hLogoBmp;
}

Bitmap* CUIHandler::GetLogoBmp()
{
    return bmpLogo;
}

WNDPROC CUIHandler::GetOrigVideoWndProc()
{
    return wpOrigVideoWndProc;
}

void CUIHandler::DrawFrame(Bitmap* frame)
{
}

void CUIHandler::Msg(const TCHAR *szFormat, ...)
{
#ifdef _DEBUG
    TCHAR szBuffer[1024];  // Large buffer for long filenames or URLs
    const size_t NUMCHARS = sizeof(szBuffer) / sizeof(szBuffer[0]);
    const int LASTCHAR = NUMCHARS - 1;

    // Format the input string
    va_list pArgs;
    va_start(pArgs, szFormat);

    // Use a bounded buffer size to prevent buffer overruns.  Limit count to
    // character size minus one to allow for a NULL terminating character.
    (void)StringCchVPrintf(szBuffer, NUMCHARS - 1, szFormat, pArgs);
    va_end(pArgs);

    // Ensure that the formatted string is NULL-terminated
    szBuffer[LASTCHAR] = TEXT('\0');

    MessageBox(NULL, szBuffer, TEXT("SmartCam Message"), MB_OK | MB_ICONERROR);
#endif
}

HWND CUIHandler::GetHWNDMainWnd()
{
    return hMainWnd;
}

HWND CUIHandler::GetHWNDVideoWnd()
{
    return hVideoWnd;
}

void CUIHandler::UpdateOnDisconnected()
{
    CreateModifyTrayIcon(hIconDisconnected, TRAY_TOOLTIP_DISCONNECTED, FALSE);
    // Disable the disconnect button
    SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_DISCONNECT, (LPARAM) MAKELONG (FALSE, 0));
    SendMessage(hVideoWnd, WM_PAINT, (WPARAM) 0, (LPARAM) 0);
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Disconnected");
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 1, (LPARAM) "FPS:");
	SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 2, (LPARAM) "Resolution:");
}

void CUIHandler::UpdateOnConnected()
{
    CreateModifyTrayIcon(hIconConnected, TRAY_TOOLTIP_CONNECTED, FALSE);
    // Enable the disconnect button
    SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_DISCONNECT, (LPARAM) MAKELONG (TRUE, 0));
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Connected");
}

void CUIHandler::UpdateOnNoNetwork()
{
    CreateModifyTrayIcon(hIconNoNetwork, TRAY_TOOLTIP_NO_NETWORK, FALSE);
    // Disable the disconnect button
    SendMessage(hToolBarWnd, TB_ENABLEBUTTON, IDM_DISCONNECT, (LPARAM) MAKELONG (FALSE, 0));
    SendMessage(hVideoWnd, WM_PAINT, (WPARAM) 0, (LPARAM) 0);
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 0, (LPARAM) "Disconnected");
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 1, (LPARAM) "FPS:");
}

void CUIHandler::UpdateStatusBarIcon()
{
    if(g_pEngine->GetSettings().connectionType == ConnectionType::CONN_BLUETOOTH)
        SendMessage(hStatusBarWnd, SB_SETICON, (WPARAM) 0, (LPARAM) hIconConnBt);
    else if(g_pEngine->GetSettings().connectionType == ConnectionType::CONN_INET)
        SendMessage(hStatusBarWnd, SB_SETICON, (WPARAM) 0, (LPARAM) hIconConnInet);
}

void CUIHandler::UpdateFPS(char* fps_str)
{
    SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 1, (LPARAM) fps_str);
}

void CUIHandler::UpdateResolution(int width, int height)
{
	char resolution_str[30];
	memset(resolution_str, 0, 30);
	sprintf(resolution_str, "Resolution: %d x %d", width, height);
	SendMessage(hStatusBarWnd, SB_SETTEXT, (WPARAM) 2, (LPARAM) resolution_str);
}
