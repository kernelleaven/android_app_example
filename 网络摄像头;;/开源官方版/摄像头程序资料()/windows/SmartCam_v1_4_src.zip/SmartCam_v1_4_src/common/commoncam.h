/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// commoncam.h

#ifndef __COMMON_CAM__
#define __COMMON_CAM__

#include <initguid.h>
#include <string>

using namespace std;

#define SMARTCAM_CLASSNAME			"SmartCam_{B9DEC6D2-2930-4338-A079-AAE560053238}"
#define SMARTCAM_CAPTION			"SmartCam"

#define FRAME_WIDTH					320//160
#define FRAME_HEIGHT				240//120

#define COMPRESSED_BUFFER_SIZE		20 * 1024 // 20 KB
#define FRAME_NUMBER_SIZE			4
#define SHARED_MEM_SIZE				FRAME_WIDTH * FRAME_HEIGHT * 3 + 1024

#define SHARED_MEM_NAME				"SmartCamShMem"
#define NEW_FRAME_EVT_NAME			"SmartCamNewFrameEvt"
#define SC_END_OF_STREAM			-1
#define SC_STREAM_DISCONNECTED		-2


// {74AD45B0-D8B4-4422-9C32-0AB6EECA21E0}
DEFINE_GUID(CLSID_SmartCam,
0x74ad45b0, 0xd8b4, 0x4422, 0x9c, 0x32, 0xa, 0xb6, 0xee, 0xca, 0x21, 0xe0);

DEFINE_GUID(g_guidServiceClass,
0xb9dec6d2, 0x2930, 0x4338, 0xa0, 0x79, 0xaa, 0xe5, 0x60, 0x5, 0x32, 0x38);

class Util
{
public:
	inline static char* GetLastErrorMessage()
	{
		static char errmsg[512];
		if(!FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,
			0,
			GetLastError(),
			0,
			errmsg,
			511,
			NULL))
		{
			// if we fail, call ourself to find out why and return that error
			return GetLastErrorMessage();
		}

		return errmsg;
	}

	inline static BOOL CreateSharedMem(LPHANDLE phFileMapping, LPVOID* ppSharedMem)
	{
		*phFileMapping = CreateFileMapping(
							INVALID_HANDLE_VALUE,		// use paging file
							NULL,						// default security attributes
							PAGE_READWRITE,				// read/write access
							0,							// size: high 32-bits
							SHARED_MEM_SIZE,			// size: low 32-bits
							SHARED_MEM_NAME);			// name of map object
		if(*phFileMapping == NULL)
		{
			*ppSharedMem = NULL;
			return FALSE;
		}
		// Get the pointer to the file-mapped shared memory.
		*ppSharedMem = MapViewOfFile(
							*phFileMapping,	// object to map view of
							FILE_MAP_WRITE,	// read/write access
							0,				// high offset:  map from
							0,				// low offset:   beginning
							0);				// default: map entire file
		if(*ppSharedMem == NULL)
		{
			CloseHandle(*phFileMapping);
			*phFileMapping = NULL;
			return FALSE;
		}
		return TRUE;
	}

	inline static BOOL CreateOpenNewFrameEvt(LPHANDLE phEvt)
	{
		*phEvt = CreateEvent(
						NULL,				// no security attributes
						FALSE,				// auto-reset event
						FALSE,				// initial state is non-signaled
						NEW_FRAME_EVT_NAME);// event object name
		if(*phEvt == NULL)
		{
			return FALSE;
		}
		return TRUE;
	}

	inline static BOOL ParseFileName(const string& fullName, string* dirPath, string* name)
	{
		if(fullName.length() == 0)
			return FALSE;
		int lastBSlashPos = fullName.find_last_of('\\');
		if(lastBSlashPos == string::npos)
			return FALSE;
		if(dirPath != NULL)
			*dirPath = fullName.substr(0, lastBSlashPos + 1);
		if(name != NULL)
			*name = fullName.substr(lastBSlashPos + 1, fullName.length() - lastBSlashPos);
		return TRUE;
	}
};


#endif//__COMMON_CAM__

