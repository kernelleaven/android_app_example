/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// MediaTypes.h

#ifndef __MEDIA_TYPES_H__
#define __MEDIA_TYPES_H__

#include "..\common\commoncam.h"

const REFERENCE_TIME FPS_10 = UNITS / 10;
const LONG AVG_FRAME_TIME_MS = 50;			// 50 ms = 20 fps

VIDEO_STREAM_CONFIG_CAPS SmartCamVideoCfgCaps = {
    FORMAT_VideoInfo,						// GUID				guid
    AnalogVideo_None,						// ULONG			VideoStandard
	{FRAME_WIDTH, FRAME_HEIGHT},			// SIZE				InputSize
	{0, 0},									// SIZE				MinCroppingSize
	{0, 0},									// SIZE				MaxCroppingSize
    0,										// int				CropGranularityX
    0,										// int				CropGranularityY
    0,										// int				CropAlignX
    0,										// int				CropAlignY
	{0, 0},									// SIZE				MinOutputSize
    {FRAME_WIDTH, FRAME_HEIGHT},			// SIZE				MaxOutputSize;
    1,										// int				OutputGranularityX
    1,										// int				OutputGranularityY
    0,										// int				StretchTapsX
    0,										// int				StretchTapsY
    0,										// int				ShrinkTapsX
    0,										// int				ShrinkTapsY
    0,										// LONGLONG			MinFrameInterval
    640000000,								// LONGLONG			MaxFrameInterval
    0,										// LONG				MinBitsPerSecond
    8 * 3 * 30 * FRAME_WIDTH * FRAME_HEIGHT	// LONG				MaxBitsPerSecond
};

VIDEOINFOHEADER SmartCamVideoInfoHeader = {
	{0, 0, 0, 0},						// RECT                rcSource,
    {0, 0, 0, 0},						// RECT                rcTarget;
    0,									// DWORD               dwBitRate;
    0,									// DWORD               dwBitErrorRate;
    0,									// REFERENCE_TIME      AvgTimePerFrame;
    // BITMAPINFOHEADER    bmiHeader;
	{
		sizeof(BITMAPINFOHEADER),		// DWORD  biSize;
		FRAME_WIDTH,					// LONG   biWidth;
		FRAME_HEIGHT,					// LONG   biHeight;
		1,								// WORD   biPlanes;
		24,								// WORD   biBitCount;
		BI_RGB,							// DWORD  biCompression;
		FRAME_WIDTH * FRAME_HEIGHT * 3,	// DWORD  biSizeImage;
		0,								// LONG   biXPelsPerMeter;
		0,								// LONG   biYPelsPerMeter;
		0,								// DWORD  biClrUsed;
		0								// DWORD  biClrImportant;
	}
};

AM_MEDIA_TYPE SmartCamMediaType = {
	MEDIATYPE_Video,					// GUID			majortype
	MEDIASUBTYPE_RGB24,					// GUID			subtype
	TRUE,								// BOOL			bFixedSizeSamples
	FALSE,								// BOOL			bTemporalCompression
	FRAME_WIDTH * FRAME_HEIGHT * 3,		// ULONG		lSampleSize
	FORMAT_VideoInfo,					// GUID			formattype
	NULL,								// IUnknown*	pUnk
	0,//sizeof(VIDEOINFOHEADER),			// ULONG		cbFormat
	NULL//(BYTE*) &SmartCamVideoInfoHeader	// BYTE*		pbFormat
};

#endif//__MEDIA_TYPES_H__
