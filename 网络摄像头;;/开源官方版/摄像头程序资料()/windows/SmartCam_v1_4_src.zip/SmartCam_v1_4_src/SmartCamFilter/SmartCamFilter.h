/*
 * Copyright (C) 2009 Ionut Dediu <deionut@yahoo.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// SmartCamFilter.h

#ifndef __SMART_CAM_FILTER_H__
#define __SMART_CAM_FILTER_H__

#include <streams.h>
#include <string>

#include "MediaTypes.h"
#include "..\common\commoncam.h"

using namespace std;

#define MAX_PROC_FILE_NAME				512
#define MASTER_APP_FILE_NAME			"SmartCam.exe"
#define SMART_CAM_FILTER_FILE_NAME		"SmartCamFilter.ax"
#define SMART_CAM_FILTER_NAME			L"SmartCam\0"
#define SMART_CAM_CAPTURE_PIN_NAME		L"Capture\0"

class CSmartCamFilter : public CSource
{
public:
	DECLARE_IUNKNOWN
    // The only allowed way to create a filter
    static CUnknown * WINAPI CreateInstance(LPUNKNOWN lpunk, HRESULT* phr);
	STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void ** ppv);
	// Overwrite CBaseFilter::GetState to return VFW_S_CANT_CUE when stopped
	STDMETHODIMP GetState(DWORD dwMilliSecsTimeout, FILTER_STATE *State);
	STDMETHODIMP SetSyncSource(IReferenceClock* pClock);
	~CSmartCamFilter(void);

private:
	// It is only allowed to to create these objects with CreateInstance
	CSmartCamFilter(LPUNKNOWN lpunk, HRESULT *phr);

	// The pin has full access to the filter
	friend class CSmartCamCapturePin;
};

class CSmartCamCapturePin : public CSourceStream, public IAMStreamConfig, public IAMPushSource, public IKsPropertySet,
						    public CBaseStreamControl
{
public:

	CSmartCamCapturePin(HRESULT *phr, CSmartCamFilter *pParent, LPCWSTR pPinName);
	~CSmartCamCapturePin();

	DECLARE_IUNKNOWN
	STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void** ppv);

	// IAMStreamConfig
	STDMETHODIMP GetFormat(AM_MEDIA_TYPE **ppmt);
	STDMETHODIMP GetNumberOfCapabilities(int *piCount, int *piSize);
	STDMETHODIMP GetStreamCaps(int iIndex, AM_MEDIA_TYPE **ppmt, BYTE *pSCC);
	STDMETHODIMP SetFormat(AM_MEDIA_TYPE *pmt);

	// IKsPropertySet
	STDMETHODIMP Set(
			REFGUID guidPropSet,
			DWORD dwPropID,
			LPVOID pInstanceData,
			DWORD cbInstanceData,
			LPVOID pPropData,
			DWORD cbPropData
			);

	STDMETHODIMP Get(
			REFGUID guidPropSet,
			DWORD dwPropID,
			LPVOID pInstanceData,
			DWORD cbInstanceData,
			LPVOID pPropData,
			DWORD cbPropData,
			DWORD *pcbReturned
			);

	STDMETHODIMP QuerySupported(
			REFGUID guidPropSet,
			DWORD dwPropID,
			DWORD *pTypeSupport
			);

	// IAMPushSource
	STDMETHODIMP GetMaxStreamOffset(REFERENCE_TIME *prtMaxOffset);
	STDMETHODIMP GetPushSourceFlags(ULONG *pFlags);
	STDMETHODIMP GetStreamOffset(REFERENCE_TIME *prtOffset);
	STDMETHODIMP SetMaxStreamOffset(REFERENCE_TIME rtMaxOffset);
	STDMETHODIMP SetPushSourceFlags(ULONG Flags);
	STDMETHODIMP SetStreamOffset(REFERENCE_TIME rtOffset);
	STDMETHODIMP GetLatency(REFERENCE_TIME *prtLatency);

	// CBasePin methods
	// set the media type for the connection
	HRESULT SetMediaType(const CMediaType *pMediaType);

	// retrieve a preferred media type
	HRESULT GetMediaType(int iPosition, CMediaType *pMediaType);
	HRESULT GetMediaType(CMediaType *pMediaType);

	// determine whether to accept a proposed media type
	HRESULT CheckMediaType(const CMediaType *pMediaType);

	// CSourceStream methods
	// Fill in the buffer
	HRESULT FillBuffer(IMediaSample *pMediaSample);

    // Ask for buffers of the size appropriate to the agreed media type
    HRESULT DecideBufferSize(
		IMemAllocator *pIMemAlloc,
		ALLOCATOR_PROPERTIES *pProperties);

	// Called when the streaming thread is initialized
	HRESULT OnThreadCreate();
	// Called when the streaming thread is about to exit
	HRESULT OnThreadDestroy();

	// IQualityControl methods
	STDMETHODIMP Notify(IBaseFilter *pSelf, Quality q);
	STDMETHODIMP SetSink(IQualityControl *piqc);

private:
	HRESULT Initialize();
	void Cleanup();

	void GetVideoInfoParameters(
		const VIDEOINFOHEADER *pvih,	// Pointer to the format header
		BYTE  * const pbData,			// Pointer to first address in buffer
		DWORD *pdwWidth,				// Returns the width in pixels
		DWORD *pdwHeight,				// Returns the height in pixels
		LONG  *plStrideInBytes,			// Add this to a row to get the new row down
		BYTE **ppbTop,					// Pointer to first byte in top row of pixels
		bool bYuv
		);

	// Shared memory
	HANDLE hFileMapping;
	LPVOID pSharedMem;
	HANDLE hNewFrameEvt;

	bool isMaster;
	DWORD frameNumber;
	CRefTime sampleTime;
};

#endif//__SMART_CAM_FILTER_H__